import Pepperoni from '../assets/pepperoni-pizza.jpg';
import Hot from '../assets/hot-pizza.jpg';
import Vegetable from '../assets/Veggie_Pizza.jpg';
import Sweetcorn from  '../assets/sweetcorn.jpg';
import Sushi from '../assets/Sushi.jpg';
import Peppersoup from '../assets/Pepper-soup.jpg';



export const menuList = [
    {
        name: 'Pepperoni Pizza',
        Image: Pepperoni,
        price: 19.99
    },
    {
        name: 'Hot Pizza',
        Image: Hot,
        price: 9.99
    },
    {
        name: 'Vegetable Pizza',
        Image: Vegetable,
        price: 14.99
    },
    {
        name: 'Sweetcorn Pizza',
        Image: Sweetcorn,
        price: 10.99
    },
    {
        name: 'Sushi',
        Image: Sushi,
        price: 3.99
    },
    {
        name: 'Pepper soup',
        Image: Peppersoup,
        price: 20.99
    },

     
]